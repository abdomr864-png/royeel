'use client'

import { useEffect } from 'react'
import Lenis from 'lenis'
import { gsap, prefersReducedMotion, ScrollTrigger } from './motion'
import { captureAttribution } from '@/lib/tracking/attribution'

// Smooth wheel scrolling on desktop, kept in sync with GSAP ScrollTrigger.
// Touch devices keep native scrolling.
export function SmoothScroll() {
  useEffect(() => {
    captureAttribution()
    if (prefersReducedMotion()) return
    const lenis = new Lenis({ lerp: 0.085, smoothWheel: true })
    window.__lenis = lenis
    lenis.on('scroll', ScrollTrigger.update)
    const tick = (time: number) => lenis.raf(time * 1000)
    gsap.ticker.add(tick)
    gsap.ticker.lagSmoothing(0)
    if (document.documentElement.dataset.intro !== 'done') lenis.stop()
    return () => {
      gsap.ticker.remove(tick)
      lenis.destroy()
      window.__lenis = undefined
    }
  }, [])
  return null
}
