'use client'

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import type { Locale } from '@/lib/i18n/config'
import type { Product, PublicSettings } from '@/lib/types'
import { track } from '@/lib/tracking/client'

type StoreState = {
  locale: Locale
  product: Product
  settings: PublicSettings
  demo: boolean
  sizeId: string | null
  setSizeId: (id: string) => void
  quantity: number
  setQuantity: (n: number) => void
  checkoutOpen: boolean
  // Increases each time the checkout opens, so its form starts fresh.
  checkoutSession: number
  openCheckout: () => void
  closeCheckout: () => void
  // Bumped when someone tries to order without a size, to draw attention to the picker.
  sizeNudge: number
  nudgeSize: () => void
}

const StoreContext = createContext<StoreState | null>(null)

export function StoreProvider({
  locale,
  product,
  settings,
  demo,
  children,
}: {
  locale: Locale
  product: Product
  settings: PublicSettings
  demo: boolean
  children: ReactNode
}) {
  const [sizeId, setSizeIdState] = useState<string | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const [checkoutSession, setCheckoutSession] = useState(0)
  const [sizeNudge, setSizeNudge] = useState(0)

  const setSizeId = useCallback(
    (id: string) => {
      setSizeIdState(id)
      setQuantity(1)
      track('AddToCart', {
        value: product.price_mad,
        contentId: product.slug,
        contentName: product.name_fr,
        quantity: 1,
      })
    },
    [product],
  )

  const openCheckout = useCallback(() => {
    setCheckoutOpen(true)
    setCheckoutSession((n) => n + 1)
    track('InitiateCheckout', {
      value: product.price_mad * quantity,
      contentId: product.slug,
      contentName: product.name_fr,
      quantity,
    })
  }, [product, quantity])

  const value = useMemo<StoreState>(
    () => ({
      locale,
      product,
      settings,
      demo,
      sizeId,
      setSizeId,
      quantity,
      setQuantity,
      checkoutOpen,
      checkoutSession,
      openCheckout,
      closeCheckout: () => setCheckoutOpen(false),
      sizeNudge,
      nudgeSize: () => setSizeNudge((n) => n + 1),
    }),
    [locale, product, settings, demo, sizeId, setSizeId, quantity, checkoutOpen, checkoutSession, openCheckout, sizeNudge],
  )

  return <StoreContext value={value}>{children}</StoreContext>
}

export function useStore() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore must be used inside StoreProvider')
  return ctx
}
