'use client'

import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { useEffect, useRef, useState, useTransition } from 'react'
import { dictionaryFor } from '@/lib/i18n/dictionaries'
import { formatPrice, normalizeMoroccanPhone } from '@/lib/format'
import { pick } from '@/lib/localize'
import { mediaUrl } from '@/lib/supabase/env'
import { placeOrder, type OrderErrorCode } from '@/lib/orders/actions'
import { getAttribution, guessSource } from '@/lib/tracking/attribution'
import { adCookies, track } from '@/lib/tracking/client'
import { ORDER_SOURCES, PAYMENT_METHODS, type OrderSource, type PaymentMethod } from '@/lib/types'
import { lockScroll } from './motion'
import { useStore } from './StoreContext'

const CITIES = [
  ['Casablanca', 'الدار البيضاء'],
  ['Rabat', 'الرباط'],
  ['Marrakech', 'مراكش'],
  ['Tanger', 'طنجة'],
  ['Fès', 'فاس'],
  ['Agadir', 'أكادير'],
  ['Meknès', 'مكناس'],
  ['Oujda', 'وجدة'],
  ['Kénitra', 'القنيطرة'],
  ['Tétouan', 'تطوان'],
  ['Salé', 'سلا'],
  ['Témara', 'تمارة'],
  ['Mohammedia', 'المحمدية'],
  ['El Jadida', 'الجديدة'],
  ['Béni Mellal', 'بني ملال'],
  ['Nador', 'الناظور'],
  ['Safi', 'آسفي'],
  ['Laâyoune', 'العيون'],
  ['Dakhla', 'الداخلة'],
  ['Essaouira', 'الصويرة'],
  ['Ifrane', 'إفران'],
  ['Al Hoceïma', 'الحسيمة'],
  ['Khouribga', 'خريبكة'],
  ['Settat', 'سطات'],
]

type Field = 'fullName' | 'phone' | 'email' | 'city' | 'address' | 'source' | 'payment'

const FIELD_OF: Partial<Record<OrderErrorCode, Field>> = {
  INVALID_NAME: 'fullName',
  INVALID_PHONE: 'phone',
  INVALID_EMAIL: 'email',
  INVALID_CITY: 'city',
  INVALID_ADDRESS: 'address',
  INVALID_SOURCE: 'source',
  PAYMENT_METHOD_UNAVAILABLE: 'payment',
}

export function CheckoutSheet() {
  const { locale, checkoutOpen, checkoutSession, closeCheckout } = useStore()
  const t = dictionaryFor(locale)

  useEffect(() => {
    if (!checkoutOpen) return
    lockScroll(true)
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && closeCheckout()
    window.addEventListener('keydown', onKey)
    return () => {
      lockScroll(false)
      window.removeEventListener('keydown', onKey)
    }
  }, [checkoutOpen, closeCheckout])

  return (
    <div
      className={`fixed inset-0 z-[70] transition-[visibility] ${checkoutOpen ? 'visible' : 'invisible delay-500'}`}
      aria-hidden={!checkoutOpen}
    >
      <div
        onClick={closeCheckout}
        className={`absolute inset-0 bg-ink/55 backdrop-blur-[3px] transition-opacity duration-500 ${checkoutOpen ? 'opacity-100' : 'opacity-0'}`}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="checkout-title"
        data-lenis-prevent
        className={`absolute inset-x-0 bottom-0 max-h-[94svh] overflow-y-auto overscroll-contain bg-ivory-light shadow-2xl transition-transform duration-500 ease-luxe md:inset-y-0 md:start-auto md:end-0 md:max-h-none md:w-[480px] ${
          checkoutOpen
            ? 'translate-y-0 md:translate-x-0'
            : 'translate-y-full md:translate-y-0 md:translate-x-full md:rtl:-translate-x-full'
        }`}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-line bg-ivory-light/95 px-5 pb-3 pt-5 backdrop-blur md:pt-4">
          <span className="absolute start-1/2 top-2 block h-1 w-10 -translate-x-1/2 rounded-full bg-line md:hidden rtl:translate-x-1/2" aria-hidden />
          <h2 id="checkout-title" className="font-display text-2xl text-burgundy">
            {t.checkout.title}
          </h2>
          <button type="button" onClick={closeCheckout} aria-label={t.checkout.close} className="-me-2 grid size-10 place-items-center text-mute hover:text-burgundy">
            <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>
        {checkoutSession > 0 ? <CheckoutForm key={checkoutSession} /> : null}
      </div>
    </div>
  )
}

// Rendered only in the browser after the first opening, with fresh state each time.
function CheckoutForm() {
  const { locale, product, settings, sizeId, quantity } = useStore()
  const t = dictionaryFor(locale)
  const router = useRouter()
  const formRef = useRef<HTMLFormElement>(null)
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<{ code: OrderErrorCode; field?: Field } | null>(null)
  const [source, setSource] = useState<OrderSource | null>(() => guessSource(getAttribution()) ?? null)
  const methods = PAYMENT_METHODS.filter((m) => settings.payments[m])
  const [method, setMethod] = useState<PaymentMethod | null>(methods[0] ?? null)

  const size = product.product_sizes.find((s) => s.id === sizeId)
  const cover = product.product_images.find((i) => i.role === 'gallery') ?? product.product_images[0]
  const subtotal = product.price_mad * quantity
  const shipping = settings.shipping_fee_mad
  const total = subtotal + shipping

  useEffect(() => {
    const first = formRef.current?.querySelector<HTMLInputElement>('input[name="fullName"]')
    const id = setTimeout(() => first?.focus({ preventScroll: true }), 350)
    return () => clearTimeout(id)
  }, [])

  function submit(form: HTMLFormElement) {
    const fd = new FormData(form)
    const value = (k: string) => String(fd.get(k) ?? '').trim()
    const phone = value('phone')

    // Quick checks before the round trip; the server checks everything again.
    const local: [boolean, OrderErrorCode][] = [
      [value('fullName').length >= 2, 'INVALID_NAME'],
      [normalizeMoroccanPhone(phone) !== null, 'INVALID_PHONE'],
      [value('city').length >= 2, 'INVALID_CITY'],
      [value('address').length >= 5, 'INVALID_ADDRESS'],
      [method !== null, 'PAYMENT_METHOD_UNAVAILABLE'],
      [!!size, 'EMPTY_CART'],
    ]
    const failed = local.find(([ok]) => !ok)
    if (failed) {
      setError({ code: failed[1], field: FIELD_OF[failed[1]] })
      return
    }

    const attribution = getAttribution()
    const cleanAttribution = Object.fromEntries(
      Object.entries(attribution).filter(([k, v]) => k !== 'at' && typeof v === 'string'),
    ) as Record<string, string>

    startTransition(async () => {
      const res = await placeOrder({
        fullName: value('fullName'),
        phone,
        email: value('email'),
        city: value('city'),
        address: value('address'),
        source,
        paymentMethod: method!,
        items: [{ sizeId: size!.id, quantity }],
        locale,
        attribution: cleanAttribution,
        website: value('website') || undefined,
        ...adCookies(),
        pageUrl: window.location.href.split('#')[0],
      })
      if (!res.ok) {
        setError({ code: res.error, field: FIELD_OF[res.error] })
        return
      }
      track('Purchase', {
        value: res.totalMad,
        contentId: product.slug,
        contentName: product.name_fr,
        quantity,
        eventId: res.orderId,
      })
      if (res.redirectTo.startsWith('/api/')) window.location.href = res.redirectTo
      else router.push(res.redirectTo)
    })
  }

  const fieldClass = (f: Field) =>
    `mt-1.5 block w-full border bg-ivory-light px-4 py-3.5 text-[1rem] text-ink outline-none transition-colors placeholder:text-mute/50 focus:border-burgundy ${
      error?.field === f ? 'border-burgundy' : 'border-line'
    }`

  return (
    <form
      ref={formRef}
      noValidate
      onSubmit={(e) => {
        e.preventDefault()
        submit(e.currentTarget)
      }}
      className="px-5 pb-8 pt-5"
    >
      {/* Summary */}
      <div className="flex gap-4 border border-line bg-ivory p-3">
        {cover ? (
          <div className="relative h-24 w-[72px] shrink-0 overflow-hidden">
            <Image src={mediaUrl(cover.path)} alt="" fill sizes="72px" className="object-cover" />
          </div>
        ) : null}
        <div className="flex flex-1 flex-col justify-center text-sm">
          <p className="font-display text-xl text-ink">{pick(product, 'name', locale)}</p>
          <p className="text-mute">
            {t.checkout.size} {size?.label ?? '—'} · × {quantity}
          </p>
          <p className="mt-1 text-ink">{formatPrice(subtotal, locale)}</p>
        </div>
      </div>

      <fieldset className="mt-7">
        <legend className="eyebrow text-gold">{t.checkout.yourDetails}</legend>
        <div className="mt-4 grid gap-4">
          <label className="block text-sm text-ink">
            {t.checkout.fullName}
            <input name="fullName" autoComplete="name" required maxLength={120} className={fieldClass('fullName')} />
          </label>
          <label className="block text-sm text-ink">
            {t.checkout.phone}
            <input
              name="phone"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              dir="ltr"
              required
              maxLength={20}
              placeholder={t.checkout.phonePlaceholder}
              className={`${fieldClass('phone')} rtl:text-right`}
            />
          </label>
          <div className="grid gap-4 sm:grid-cols-[1fr_1.4fr]">
            <label className="block text-sm text-ink">
              {t.checkout.city}
              <input name="city" list="ma-cities" autoComplete="address-level2" required maxLength={80} placeholder={t.checkout.cityPlaceholder} className={fieldClass('city')} />
            </label>
            <label className="block text-sm text-ink">
              {t.checkout.address}
              <input name="address" autoComplete="street-address" required maxLength={300} placeholder={t.checkout.addressPlaceholder} className={fieldClass('address')} />
            </label>
          </div>
          <datalist id="ma-cities">
            {CITIES.map(([fr, ar]) => (
              <option key={fr} value={locale === 'ar' ? ar : fr} />
            ))}
          </datalist>
          <label className="block text-sm text-ink">
            {t.checkout.email} <span className="text-mute">({t.checkout.optional})</span>
            <input name="email" type="email" inputMode="email" autoComplete="email" dir="ltr" maxLength={200} className={`${fieldClass('email')} rtl:text-right`} />
            <span className="mt-1 block text-xs text-mute">{t.checkout.emailHint}</span>
          </label>
          {/* Honeypot for bots */}
          <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
        </div>
      </fieldset>

      <fieldset className="mt-7">
        <legend className="text-sm text-ink">{t.checkout.sourceQuestion}</legend>
        <div className="mt-3 flex flex-wrap gap-2">
          {ORDER_SOURCES.map((s) => (
            <button
              key={s}
              type="button"
              aria-pressed={source === s}
              onClick={() => setSource(source === s ? null : s)}
              className={`rounded-full border px-4 py-2 text-sm transition-colors ${
                source === s ? 'border-burgundy bg-burgundy text-ivory' : 'border-line text-ink hover:border-burgundy'
              }`}
            >
              {t.checkout.sources[s]}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="mt-7">
        <legend className="eyebrow text-gold">{t.checkout.payment}</legend>
        <div role="radiogroup" className="mt-4 grid gap-2">
          {methods.map((m) => (
            <label
              key={m}
              className={`flex cursor-pointer items-start gap-3 border p-4 transition-colors ${
                method === m ? 'border-burgundy bg-ivory' : 'border-line hover:border-burgundy/50'
              }`}
            >
              <input
                type="radio"
                name="payment"
                value={m}
                checked={method === m}
                onChange={() => {
                  setMethod(m)
                  track('AddPaymentInfo', { value: total, contentId: product.slug })
                }}
                className="mt-1 accent-burgundy"
              />
              <span>
                <span className="block text-[0.95rem] text-ink">{t.checkout.methods[m].label}</span>
                <span className="block text-sm text-mute">{t.checkout.methods[m].hint}</span>
              </span>
            </label>
          ))}
        </div>
      </fieldset>

      <dl className="mt-7 grid gap-2 border-t border-line pt-5 text-sm">
        <div className="flex justify-between text-mute">
          <dt>{t.checkout.subtotal}</dt>
          <dd>{formatPrice(subtotal, locale)}</dd>
        </div>
        <div className="flex justify-between text-mute">
          <dt>{t.checkout.shipping}</dt>
          <dd>{shipping ? formatPrice(shipping, locale) : t.checkout.free}</dd>
        </div>
        <div className="flex justify-between pt-2 font-display text-2xl text-ink">
          <dt>{t.checkout.total}</dt>
          <dd>{formatPrice(total, locale)}</dd>
        </div>
      </dl>

      {error ? (
        <p role="alert" className="mt-5 border-s-2 border-burgundy bg-burgundy/5 px-4 py-3 text-sm text-burgundy">
          {t.checkout.errors[error.code]}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={pending || methods.length === 0}
        className="mt-6 flex h-14 w-full items-center justify-center bg-burgundy text-[0.8125rem] font-medium uppercase tracking-[0.22em] text-ivory transition-colors hover:bg-burgundy-soft disabled:opacity-60 rtl:text-base rtl:tracking-normal"
      >
        {pending ? t.checkout.submitting : `${t.checkout.submit} · ${formatPrice(total, locale)}`}
      </button>
      <p className="mt-3 text-center text-xs text-mute">{t.checkout.trust}</p>
    </form>
  )
}
