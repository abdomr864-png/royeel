import Link from 'next/link'
import { cacheLife } from 'next/cache'
import { Ornament, Swan, Tagline, Wordmark } from '@/components/brand/Logo'
import type { Dictionary } from '@/lib/i18n/dictionaries'
import type { Locale } from '@/lib/i18n/config'
import { whatsappLink } from '@/lib/format'
import type { PublicSettings } from '@/lib/types'

const PERK_ICONS = {
  delivery: 'M3 7h11v9H3zM14 10h4l3 3v3h-7zM7 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM17.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z',
  cod: 'M3 7h18v10H3zM12 14.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zM6 10v4M18 10v4',
  exchange: 'M4 9h13l-3-3M20 15H7l3 3',
}

export function Perks({ t }: { t: Dictionary }) {
  const perks = [
    { key: 'delivery', ...t.perks.delivery },
    { key: 'cod', ...t.perks.cod },
    { key: 'exchange', ...t.perks.exchange },
  ] as const
  return (
    <section className="bg-burgundy px-5 py-14 text-ivory md:px-10 md:py-16">
      <ul className="mx-auto grid max-w-[1100px] gap-10 text-center md:grid-cols-3 md:gap-6">
        {perks.map((p, i) => (
          <li key={p.key} className={`flex flex-col items-center gap-3 ${i ? 'md:border-s md:border-ivory/15' : ''}`}>
            <svg viewBox="0 0 24 24" className="size-7 text-gold-light" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" strokeLinecap="round">
              <path d={PERK_ICONS[p.key]} />
            </svg>
            <p className="font-display text-2xl">{p.title}</p>
            <p className="text-sm text-ivory/60">{p.text}</p>
          </li>
        ))}
      </ul>
    </section>
  )
}

export function Faq({ t }: { t: Dictionary }) {
  return (
    <section className="bg-ivory-light px-5 py-24 md:px-10 md:py-32">
      <div className="mx-auto max-w-[760px]">
        <h2 className="text-center font-display text-[clamp(2rem,5vw,3.25rem)] font-light text-burgundy">{t.faq.heading}</h2>
        <Ornament className="mx-auto mt-5 w-36 text-gold" />
        <div className="mt-12 border-t border-line">
          {t.faq.items.map((item) => (
            <details key={item.q} className="group border-b border-line">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 py-6 font-display text-xl text-ink md:text-2xl [&::-webkit-details-marker]:hidden">
                {item.q}
                <span className="relative size-3 shrink-0 text-gold">
                  <span className="absolute inset-x-0 top-1/2 h-px bg-current" />
                  <span className="absolute inset-y-0 start-1/2 w-px bg-current transition-transform duration-300 group-open:rotate-90 group-open:opacity-0" />
                </span>
              </summary>
              <p className="pb-6 leading-relaxed text-mute">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}

async function currentYear() {
  'use cache'
  cacheLife('days')
  return new Date().getFullYear()
}

export async function Footer({ t, locale, settings }: { t: Dictionary; locale: Locale; settings: PublicSettings }) {
  const socials = [
    { label: 'Instagram', href: settings.instagram_url },
    { label: 'TikTok', href: settings.tiktok_url },
    { label: 'Facebook', href: settings.facebook_url },
  ].filter((s) => s.href)
  const year = await currentYear()
  return (
    <footer className="bg-burgundy-deep px-5 pb-28 pt-20 text-ivory md:px-10 md:pb-12">
      <div className="mx-auto flex max-w-[1200px] flex-col items-center text-center">
        <Swan className="w-20 text-ivory" />
        <Wordmark className="mt-5 w-48" title="Royeel" />
        <Ornament className="mt-3 w-32 text-gold-light/70" />
        <Tagline className="mt-3 w-36 text-ivory/70" />
        <p className="mt-6 max-w-xs text-sm text-ivory/55">{t.footer.about}</p>

        <nav className="mt-10 flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm text-ivory/75">
          <Link href={`/${locale}/conditions`} className="hover:text-ivory">
            {t.footer.legal.conditions}
          </Link>
          <Link href={`/${locale}/echanges`} className="hover:text-ivory">
            {t.footer.legal.exchanges}
          </Link>
          <Link href={`/${locale}/confidentialite`} className="hover:text-ivory">
            {t.footer.legal.privacy}
          </Link>
          {settings.whatsapp_number ? (
            <a href={whatsappLink(settings.whatsapp_number)} target="_blank" rel="noopener noreferrer" className="hover:text-ivory">
              {t.footer.contactWhatsapp}
            </a>
          ) : null}
          {socials.map((s) => (
            <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer" className="hover:text-ivory">
              {s.label}
            </a>
          ))}
        </nav>
        <p className="mt-12 text-xs text-ivory/35">{t.footer.rights(year)}</p>
      </div>
    </footer>
  )
}
