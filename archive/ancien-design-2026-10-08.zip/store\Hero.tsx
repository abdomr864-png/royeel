'use client'

import Image from 'next/image'
import { useRef } from 'react'
import { useGSAP } from '@gsap/react'
import { Ornament, Wordmark } from '@/components/brand/Logo'
import { dictionaryFor } from '@/lib/i18n/dictionaries'
import { formatPrice } from '@/lib/format'
import { pick } from '@/lib/localize'
import { mediaUrl } from '@/lib/supabase/env'
import { afterIntro, gsap, prefersReducedMotion, scrollToId } from './motion'
import { useStore } from './StoreContext'

export function Hero() {
  const { locale, product } = useStore()
  const t = dictionaryFor(locale)
  const root = useRef<HTMLElement>(null)

  const name = pick(product, 'name', locale)
  const words = name.split(' ')
  const nameLines = words.length > 1 ? [words.slice(0, -1).join(' '), words.at(-1)!] : [name]
  const cover = product.product_images.find((i) => i.role === 'gallery') ?? product.product_images[0]

  useGSAP(
    (_, contextSafe) => {
      if (prefersReducedMotion()) return
      // Resolve elements now: the entrance runs later, outside this scope.
      const q = gsap.utils.selector(root)
      const lines = q('[data-h="line"] > span')
      const fades = q('[data-h="fade"]')
      const frame = q('[data-h="frame"]')
      const img = q('[data-h="img"]')
      gsap.set(lines, { yPercent: 110 })
      gsap.set(fades, { opacity: 0, y: 16 })
      gsap.set(frame, { clipPath: 'inset(100% 0% 0% 0%)' })
      gsap.set(img, { scale: 1.25 })

      const cleanup = afterIntro(
        contextSafe!(() => {
          gsap
            .timeline({ defaults: { ease: 'expo.out' } })
            .to(frame, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.6 })
            .to(img, { scale: 1, duration: 2.2 }, 0)
            .to(lines, { yPercent: 0, duration: 1.3, stagger: 0.12 }, 0.25)
            .to(fades, { opacity: 1, y: 0, duration: 1, stagger: 0.08 }, 0.6)
        }),
      )

      // Drift apart as the visitor scrolls away.
      gsap.to('[data-h="media"]', {
        yPercent: -12,
        ease: 'none',
        scrollTrigger: { trigger: root.current, start: 'top top', end: 'bottom top', scrub: true },
      })
      gsap.to('[data-h="copy"]', {
        yPercent: 18,
        opacity: 0.2,
        ease: 'none',
        scrollTrigger: { trigger: root.current, start: 'top top', end: 'bottom top', scrub: true },
      })
      return cleanup
    },
    { scope: root },
  )

  return (
    <section ref={root} className="relative isolate min-h-[100svh] overflow-hidden bg-burgundy text-ivory">
      {/* Oversized wordmark watermark */}
      <Wordmark
        aria-hidden
        className="pointer-events-none absolute -bottom-[2vw] start-1/2 -z-10 w-[130vw] max-w-none -translate-x-1/2 text-ivory/[0.045] rtl:translate-x-1/2 md:w-[110vw]"
      />
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_70%_35%,rgba(184,151,90,0.16),transparent_55%)]" />

      <div className="mx-auto grid min-h-[100svh] max-w-[1400px] content-center items-center gap-6 px-5 pb-10 pt-[calc(5rem+var(--contact-bar,0px))] md:grid-cols-[1fr_1.05fr] md:gap-12 md:px-10 md:pb-16 md:pt-[calc(7rem+var(--contact-bar,0px))]">
        <div data-h="copy" className="order-2 text-center md:order-1 md:text-start">
          <p data-h="fade" className="eyebrow text-gold-light">
            {t.hero.eyebrow}
          </p>
          <h1 className="mt-3 font-display text-[clamp(2.6rem,10vw,7.25rem)] font-light italic leading-[0.92] tracking-[-0.01em] rtl:not-italic rtl:leading-[1.15]">
            {nameLines.map((l) => (
              <span key={l} data-h="line" className="line-mask">
                <span className="block">{l}</span>
              </span>
            ))}
          </h1>
          <p data-h="fade" className="mx-auto mt-3 max-w-sm text-[0.95rem] text-ivory/70 md:mx-0 md:mt-5">
            {pick(product, 'subtitle', locale)}
          </p>
          <div data-h="fade" className="mt-5 flex flex-wrap items-center justify-center gap-5 md:mt-8 md:justify-start">
            <span className="font-display text-3xl tracking-wide">{formatPrice(product.price_mad, locale)}</span>
            <button
              type="button"
              onClick={() => scrollToId('acheter')}
              className="group relative overflow-hidden rounded-full bg-ivory px-8 py-3.5 text-[0.8125rem] font-medium uppercase tracking-[0.18em] text-burgundy transition-transform duration-500 ease-luxe hover:scale-[1.03] rtl:tracking-normal"
            >
              <span className="relative z-10">{t.hero.cta}</span>
              <span className="absolute inset-0 -translate-x-full bg-gold-light transition-transform duration-500 ease-luxe group-hover:translate-x-0 rtl:translate-x-full" />
            </button>
          </div>
        </div>

        <div data-h="media" className="relative order-1 mx-auto w-[min(58vw,40svh,460px)] md:order-2 md:w-[min(38vw,520px)]">
          <div className="arch border border-ivory/25 p-1.5 md:p-3">
            <div data-h="frame" className="arch relative aspect-[3/4] overflow-hidden bg-burgundy-deep md:aspect-[3/4.2]">
              {cover ? (
                <Image
                  data-h="img"
                  src={mediaUrl(cover.path)}
                  alt={pick(cover, 'alt', locale)}
                  fill
                  priority
                  sizes="(min-width: 768px) 40vw, 60vw"
                  className="object-cover object-top"
                />
              ) : null}
            </div>
          </div>
          <Ornament data-h="fade" className="mx-auto mt-4 hidden w-40 text-gold-light/80 md:block" />
        </div>
      </div>

      <button
        type="button"
        onClick={() => scrollToId('details')}
        className="absolute bottom-6 start-1/2 hidden -translate-x-1/2 flex-col items-center gap-3 text-ivory/50 transition-colors hover:text-ivory md:flex rtl:translate-x-1/2"
      >
        <span className="eyebrow">{t.hero.scroll}</span>
        <span className="block h-10 w-px origin-top animate-pulse bg-current" />
      </button>
    </section>
  )
}
