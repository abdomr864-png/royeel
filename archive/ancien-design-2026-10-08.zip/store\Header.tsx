'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { Wordmark } from '@/components/brand/Logo'
import { dictionaryFor } from '@/lib/i18n/dictionaries'
import { LOCALE_COOKIE, type Locale } from '@/lib/i18n/config'
import { scrollToId } from './motion'

export function Header({ locale }: { locale: Locale }) {
  const t = dictionaryFor(locale)
  const [solid, setSolid] = useState(false)
  const other: Locale = locale === 'fr' ? 'ar' : 'fr'

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 40)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed inset-x-0 top-[var(--contact-bar,0px)] z-40 transition-[background-color,color,box-shadow] duration-500 ease-luxe ${
        solid ? 'bg-ivory-light/85 text-burgundy shadow-[0_1px_0_var(--color-line)] backdrop-blur-md' : 'text-ivory'
      }`}
    >
      <div className="mx-auto grid h-16 max-w-[1400px] grid-cols-[1fr_auto_1fr] items-center px-4 md:h-20 md:px-10">
        <Link
          href={`/${other}`}
          hrefLang={other}
          aria-label={t.nav.switchToLabel}
          onClick={() => {
            document.cookie = `${LOCALE_COOKIE}=${other}; path=/; max-age=31536000; SameSite=Lax`
          }}
          className="justify-self-start text-sm tracking-wide opacity-80 transition-opacity hover:opacity-100"
        >
          {t.nav.switchTo}
        </Link>

        <Link href={`/${locale}`} aria-label="Royeel" className="justify-self-center">
          <Wordmark className="h-[18px] w-auto md:h-[22px]" />
        </Link>

        <button
          type="button"
          onClick={() => scrollToId('acheter')}
          className={`justify-self-end rounded-full border px-4 py-2 text-[0.8125rem] tracking-wide transition-colors duration-300 md:px-6 ${
            solid
              ? 'border-burgundy bg-burgundy text-ivory hover:bg-burgundy-soft'
              : 'border-ivory/50 hover:border-ivory hover:bg-ivory hover:text-burgundy'
          }`}
        >
          {t.nav.order}
        </button>
      </div>
    </header>
  )
}
