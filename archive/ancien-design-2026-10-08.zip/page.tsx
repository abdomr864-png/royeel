import { getStorefront } from '@/lib/catalog'
import { getDictionary, getLocale } from '@/lib/i18n/get-dictionary'
import { FullLogo } from '@/components/brand/Logo'
import { CheckoutSheet } from '@/components/store/CheckoutSheet'
import { Details } from '@/components/store/Details'
import { Header } from '@/components/store/Header'
import { Hero } from '@/components/store/Hero'
import { Intro } from '@/components/store/Intro'
import { Purchase } from '@/components/store/Purchase'
import { Faq, Footer, Perks } from '@/components/store/Sections'
import { SmoothScroll } from '@/components/store/SmoothScroll'
import { StickyBar } from '@/components/store/StickyBar'
import { StoreProvider } from '@/components/store/StoreContext'
import { Turntable } from '@/components/store/Turntable'

export default async function StorePage() {
  const locale = await getLocale()
  const t = await getDictionary()
  const { product, settings, demo } = await getStorefront()

  if (!product) {
    return (
      <main className="grid min-h-svh place-items-center bg-burgundy px-6 text-ivory">
        <FullLogo className="w-[min(70vw,360px)]" />
      </main>
    )
  }

  return (
    <StoreProvider locale={locale} product={product} settings={settings} demo={demo}>
      <SmoothScroll />
      <Intro skipLabel={t.intro.skip} />
      <Header locale={locale} />
      <main>
        <Hero />
        <Details />
        <Turntable />
        <Purchase />
        <Perks t={t} />
        <Faq t={t} />
      </main>
      <Footer t={t} locale={locale} settings={settings} />
      <StickyBar />
      <CheckoutSheet />
      {demo ? (
        <p className="pointer-events-none fixed inset-x-0 top-[calc(4rem+var(--contact-bar,0px))] z-30 mx-auto w-fit max-w-[92vw] bg-ink/80 px-3 py-1.5 text-center text-[11px] leading-snug text-ivory md:top-[calc(5rem+var(--contact-bar,0px))]">
          {t.demoBanner}
        </p>
      ) : null}
    </StoreProvider>
  )
}
