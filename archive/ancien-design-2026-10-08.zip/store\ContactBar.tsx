'use client'

import { dictionaryFor } from '@/lib/i18n/dictionaries'
import type { Locale } from '@/lib/i18n/config'
import { whatsappLink } from '@/lib/format'
import { track } from '@/lib/tracking/client'

// Thin bar fixed at the top of every shop page: one tap opens WhatsApp with a
// message already written. Hidden until a WhatsApp number is set in the admin.
export function ContactBar({ locale, number }: { locale: Locale; number: string }) {
  if (!number) return null
  const t = dictionaryFor(locale).contactBar
  return (
    <a
      href={whatsappLink(number, t.message)}
      target="_blank"
      rel="noopener noreferrer"
      onClick={() => track('Contact')}
      className="fixed inset-x-0 top-0 z-50 flex h-[var(--contact-bar)] items-center justify-center gap-2 bg-burgundy-deep px-4 text-[0.75rem] text-ivory/85 transition-colors hover:bg-[#45101a] hover:text-ivory md:text-[0.8125rem]"
    >
      <WhatsAppIcon className="size-4 shrink-0 text-[#4fce8a]" />
      <span className="truncate md:hidden">{t.short}</span>
      <span className="hidden truncate md:inline">{t.long}</span>
      <span aria-hidden className="text-ivory/50 rtl:rotate-180">→</span>
    </a>
  )
}

// Round WhatsApp button in the bottom corner of every shop page. On phones it
// sits above the "Commander" bar.
export function WhatsAppButton({ locale, number }: { locale: Locale; number: string }) {
  if (!number) return null
  const t = dictionaryFor(locale).contactBar
  return (
    <a
      href={whatsappLink(number, t.message)}
      target="_blank"
      rel="noopener noreferrer"
      onClick={() => track('Contact')}
      aria-label={t.button}
      title={t.button}
      className="fixed bottom-24 end-4 z-40 grid size-14 place-items-center rounded-full bg-[#25d366] text-white shadow-[0_10px_30px_rgba(0,0,0,0.25)] transition-transform duration-300 hover:scale-105 md:bottom-8 md:end-8"
    >
      <span aria-hidden className="absolute inset-0 animate-ping rounded-full bg-[#25d366] opacity-30 [animation-iteration-count:3]" />
      <WhatsAppIcon className="relative size-7" />
    </a>
  )
}

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.3-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .1-1.3c0-.1-.2-.2-.4-.3z" />
    </svg>
  )
}
