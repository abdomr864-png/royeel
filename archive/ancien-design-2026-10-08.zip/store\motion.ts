'use client'

import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import type Lenis from 'lenis'

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger)
}

export { gsap, ScrollTrigger }

declare global {
  interface Window {
    __lenis?: Lenis
  }
}

export function prefersReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

export function scrollToId(id: string) {
  const el = document.getElementById(id)
  if (!el) return
  if (window.__lenis) window.__lenis.scrollTo(el, { offset: -8, duration: 1.4 })
  else el.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'start' })
}

export function lockScroll(locked: boolean) {
  if (window.__lenis) {
    if (locked) window.__lenis.stop()
    else window.__lenis.start()
  }
  document.documentElement.style.overflow = locked ? 'hidden' : ''
}

export const INTRO_DONE_EVENT = 'royeel:intro-done'

export function introFinished() {
  return document.documentElement.dataset.intro === 'done'
}

// Runs `fn` once the intro overlay is gone (immediately if it already is).
export function afterIntro(fn: () => void) {
  if (introFinished()) {
    fn()
    return () => {}
  }
  const handler = () => fn()
  window.addEventListener(INTRO_DONE_EVENT, handler, { once: true })
  return () => window.removeEventListener(INTRO_DONE_EVENT, handler)
}
