'use client'

import { useEffect, useRef } from 'react'
import { useGSAP } from '@gsap/react'
import { Ornament, Swan, Tagline, Wordmark } from '@/components/brand/Logo'
import { gsap, INTRO_DONE_EVENT, lockScroll } from './motion'

const SEEN_KEY = 'royeel_intro_seen'

// Shown once per visit: the swan rises, ROYEEL is drawn in, then the burgundy
// curtain lifts onto the coat.
export function Intro({ skipLabel }: { skipLabel: string }) {
  const root = useRef<HTMLDivElement>(null)
  const tl = useRef<gsap.core.Timeline | null>(null)

  useEffect(() => {
    if (document.documentElement.dataset.intro === 'done') return
    lockScroll(true)
    return () => lockScroll(false)
  }, [])

  useGSAP(
    () => {
      if (document.documentElement.dataset.intro === 'done') return
      const finish = () => {
        document.documentElement.dataset.intro = 'done'
        try {
          sessionStorage.setItem(SEEN_KEY, '1')
        } catch {}
        lockScroll(false)
        // Outside the intro's animation callback, so listeners start fresh.
        setTimeout(() => window.dispatchEvent(new Event(INTRO_DONE_EVENT)), 0)
      }
      // On a slow connection the CSS fallback may already have hidden it.
      if (root.current && getComputedStyle(root.current).visibility === 'hidden') {
        finish()
        return
      }
      // Otherwise JavaScript takes over from the CSS fallback.
      gsap.set(root.current, { animation: 'none' })
      tl.current = gsap
        .timeline({ defaults: { ease: 'expo.out' }, onComplete: finish })
        .from('[data-i="swan"]', { yPercent: 40, opacity: 0, clipPath: 'inset(100% 0 0 0)', duration: 1.4 })
        .from('[data-i="word"]', { clipPath: 'inset(0 50% 0 50%)', opacity: 0, duration: 1.3 }, '-=0.85')
        .from('[data-i="orn"]', { scaleX: 0, opacity: 0, duration: 0.9 }, '-=0.8')
        .from('[data-i="tag"]', { opacity: 0, y: 8, duration: 0.8 }, '-=0.55')
        .to('[data-i="logo"]', { y: -30, opacity: 0, duration: 0.7, ease: 'power3.in' }, '+=0.35')
        .to(root.current, { clipPath: 'inset(0 0 100% 0)', duration: 1.1, ease: 'expo.inOut' }, '-=0.25')
        .set(root.current, { display: 'none' })
    },
    { scope: root },
  )

  return (
    <div
      ref={root}
      className="intro fixed inset-0 z-[100] flex items-center justify-center bg-burgundy text-ivory"
      style={{ clipPath: 'inset(0 0 0% 0)' }}
    >
      <div data-i="logo" className="flex w-[min(72vw,420px)] flex-col items-center">
        <Swan data-i="swan" className="w-[38%]" />
        <Wordmark data-i="word" className="mt-[7%] w-full" title="Royeel" />
        <Ornament data-i="orn" className="mt-[4%] w-[56%] text-gold-light" />
        <Tagline data-i="tag" className="mt-[4%] w-[52%] opacity-80" />
      </div>
      <button
        type="button"
        onClick={() => tl.current?.progress(1)}
        className="eyebrow absolute bottom-8 end-6 text-ivory/60 transition-colors hover:text-ivory"
      >
        {skipLabel}
      </button>
    </div>
  )
}

// Inline script for <head>: skips the intro for returning visitors and for
// people who prefer reduced motion, before the first paint.
export const introBootScript = `try{if(sessionStorage.getItem('${SEEN_KEY}')||matchMedia('(prefers-reduced-motion: reduce)').matches)document.documentElement.dataset.intro='done'}catch(e){}`
