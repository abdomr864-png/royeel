'use client'

import dynamic from 'next/dynamic'
import Image from 'next/image'
import { useEffect, useRef, useState } from 'react'
import { dictionaryFor } from '@/lib/i18n/dictionaries'
import { pick } from '@/lib/localize'
import { mediaUrl } from '@/lib/supabase/env'
import { prefersReducedMotion } from './motion'
import { useStore } from './StoreContext'

const ModelViewer = dynamic(() => import('./ModelViewer'), { ssr: false })

// "Turn it around": the 3D model when one is uploaded, otherwise a 3D ring of
// the product photos that turns on its own and follows the visitor's finger.
export function Turntable() {
  const { locale, product } = useStore()
  const t = dictionaryFor(locale)
  const section = useRef<HTMLElement>(null)
  const [near, setNear] = useState(false)

  // Load the 3D engine only when the section is about to be seen.
  useEffect(() => {
    const el = section.current
    if (!el) return
    const io = new IntersectionObserver(([entry]) => entry.isIntersecting && setNear(true), { rootMargin: '400px' })
    io.observe(el)
    return () => io.disconnect()
  }, [])

  const modelUrl = product.model_3d_path ? mediaUrl(product.model_3d_path) : null

  return (
    <section ref={section} className="relative overflow-hidden bg-burgundy-deep py-24 text-ivory md:py-32">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_55%,rgba(216,191,140,0.14),transparent_60%)]" />
      <div className="relative mx-auto max-w-[1200px] px-5 text-center md:px-10">
        <p className="eyebrow text-gold-light">{t.viewer.eyebrow}</p>
        <h2 className="mt-4 font-display text-[clamp(2.25rem,6vw,4.5rem)] font-light italic leading-[1.05] rtl:not-italic rtl:leading-[1.3]">
          {t.viewer.heading}
        </h2>
      </div>

      <div className="relative mx-auto mt-10 h-[min(70svh,620px)] max-w-[1200px] md:mt-14">
        {modelUrl ? (
          near ? (
            <ModelViewer url={modelUrl} label={pick(product, 'name', locale)} />
          ) : (
            <p className="grid h-full place-items-center text-sm text-ivory/50">{t.viewer.loading}</p>
          )
        ) : (
          <PhotoRing />
        )}
      </div>

      <p className="relative mt-6 flex items-center justify-center gap-3 text-[0.8125rem] text-ivory/55">
        <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3M18 3v4h-4M6 21v-4h4" />
        </svg>
        {t.viewer.hint}
      </p>
    </section>
  )
}

function PhotoRing() {
  const { locale, product } = useStore()
  const images = product.product_images
  const ring = useRef<HTMLDivElement>(null)
  const angle = useRef(0)
  const velocity = useRef(0)
  const dragging = useRef<{ x: number; last: number } | null>(null)
  const [radius, setRadius] = useState(420)

  const n = Math.max(images.length, 3)
  const step = 360 / n

  useEffect(() => {
    const resize = () => {
      const panel = Math.min(window.innerWidth * 0.5, 300)
      // Distance that places the panels edge to edge around the circle.
      setRadius(Math.round(panel / 2 / Math.tan(Math.PI / n)) + 40)
    }
    resize()
    window.addEventListener('resize', resize)
    return () => window.removeEventListener('resize', resize)
  }, [n])

  useEffect(() => {
    const reduced = prefersReducedMotion()
    let raf = 0
    let visible = true
    const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting))
    if (ring.current) io.observe(ring.current)
    const loop = () => {
      if (visible && !dragging.current) {
        velocity.current *= 0.94
        const idle = reduced ? 0 : 0.12
        angle.current += Math.abs(velocity.current) > idle ? velocity.current : idle
      }
      if (ring.current) ring.current.style.transform = `translateZ(${-radius}px) rotateY(${angle.current}deg)`
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      io.disconnect()
    }
  }, [radius])

  return (
    <div
      className="absolute inset-0 cursor-grab touch-pan-y select-none active:cursor-grabbing"
      style={{ perspective: '1400px' }}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId)
        dragging.current = { x: e.clientX, last: e.clientX }
        velocity.current = 0
      }}
      onPointerMove={(e) => {
        const d = dragging.current
        if (!d) return
        const delta = (e.clientX - d.last) * 0.25
        angle.current += delta
        velocity.current = delta
        d.last = e.clientX
      }}
      onPointerUp={() => (dragging.current = null)}
      onPointerCancel={() => (dragging.current = null)}
    >
      <div ref={ring} className="absolute inset-0 m-auto h-[78%] w-[min(50vw,300px)]" style={{ transformStyle: 'preserve-3d' }}>
        {images.map((img, i) => (
          <figure
            key={img.id}
            className="absolute inset-0 overflow-hidden border border-ivory/15 bg-burgundy shadow-[0_30px_80px_rgba(0,0,0,0.45)] [backface-visibility:hidden]"
            style={{ transform: `rotateY(${i * step}deg) translateZ(${radius}px)` }}
          >
            <Image
              src={mediaUrl(img.path)}
              alt={pick(img, 'alt', locale)}
              fill
              sizes="300px"
              draggable={false}
              className="pointer-events-none object-cover"
            />
          </figure>
        ))}
      </div>
    </div>
  )
}
