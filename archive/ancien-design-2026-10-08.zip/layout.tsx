import type { Metadata, Viewport } from 'next'
import '../globals.css'
import { fontVariables } from '@/lib/fonts'
import { dirOf, locales } from '@/lib/i18n/config'
import { getDictionary, getLocale } from '@/lib/i18n/get-dictionary'
import { getStorefront } from '@/lib/catalog'
import { introBootScript } from '@/components/store/Intro'
import { Pixels } from '@/components/store/Pixels'
import { ContactBar, WhatsAppButton } from '@/components/store/ContactBar'

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }))
}

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'

export async function generateMetadata(): Promise<Metadata> {
  const locale = await getLocale()
  const t = await getDictionary()
  return {
    metadataBase: new URL(SITE_URL),
    title: { default: t.meta.title, template: '%s · Royeel' },
    description: t.meta.description,
    alternates: { canonical: `/${locale}`, languages: { fr: '/fr', ar: '/ar' } },
    openGraph: {
      type: 'website',
      siteName: 'Royeel',
      locale: locale === 'ar' ? 'ar_MA' : 'fr_MA',
      title: t.meta.title,
      description: t.meta.description,
      images: [{ url: '/brand/og.png', width: 1200, height: 630, alt: 'Royeel' }],
    },
    icons: { icon: '/brand/icon.svg', apple: '/brand/apple-icon.png' },
  }
}

export const viewport: Viewport = {
  themeColor: '#4d131c',
  width: 'device-width',
  initialScale: 1,
}

export default async function StoreLayout({ children }: LayoutProps<'/[locale]'>) {
  const locale = await getLocale()
  const { settings } = await getStorefront()
  return (
    <html
      lang={locale}
      dir={dirOf(locale)}
      className={fontVariables}
      // Height of the WhatsApp bar; the header and hero sit below it.
      style={{ '--contact-bar': settings.whatsapp_number ? '2.25rem' : '0px' } as React.CSSProperties}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: introBootScript }} />
      </head>
      <body>
        <ContactBar locale={locale} number={settings.whatsapp_number} />
        {children}
        <WhatsAppButton locale={locale} number={settings.whatsapp_number} />
        <Pixels metaPixelId={settings.meta_pixel_id} tiktokPixelId={settings.tiktok_pixel_id} />
      </body>
    </html>
  )
}
