'use client'

import { useEffect, useState } from 'react'
import { dictionaryFor } from '@/lib/i18n/dictionaries'
import { formatPrice } from '@/lib/format'
import { pick } from '@/lib/localize'
import { scrollToId } from './motion'
import { useStore } from './StoreContext'

// Phone-only bar that keeps the order button in reach between the hero and the
// purchase section.
export function StickyBar() {
  const { locale, product, checkoutOpen } = useStore()
  const t = dictionaryFor(locale)
  const [show, setShow] = useState(false)

  useEffect(() => {
    const onScroll = () => {
      const buy = document.getElementById('acheter')?.getBoundingClientRect()
      const pastHero = window.scrollY > window.innerHeight * 0.9
      const buyVisible = buy ? buy.top < window.innerHeight && buy.bottom > 0 : false
      setShow(pastHero && !buyVisible)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-30 border-t border-line bg-ivory-light/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur transition-transform duration-500 ease-luxe md:hidden ${
        show && !checkoutOpen ? 'translate-y-0' : 'translate-y-full'
      }`}
    >
      <div className="flex items-center gap-3">
        <div className="min-w-0 flex-1">
          <p className="truncate font-display text-lg leading-tight text-ink">{pick(product, 'name', locale)}</p>
          <p className="text-sm text-mute">{formatPrice(product.price_mad, locale)}</p>
        </div>
        <button
          type="button"
          onClick={() => scrollToId('acheter')}
          className="h-12 bg-burgundy px-6 text-[0.75rem] font-medium uppercase tracking-[0.2em] text-ivory rtl:text-sm rtl:tracking-normal"
        >
          {t.stickyBar.order}
        </button>
      </div>
    </div>
  )
}
