'use client'

import Image from 'next/image'
import { useRef, useState } from 'react'
import { useGSAP } from '@gsap/react'
import { dictionaryFor } from '@/lib/i18n/dictionaries'
import { pick } from '@/lib/localize'
import { mediaUrl } from '@/lib/supabase/env'
import { gsap, prefersReducedMotion } from './motion'
import { useStore } from './StoreContext'
import { ZoomViewer } from './ZoomViewer'

// One chapter per close-up photo (role "detail"), alternating sides.
export function Details() {
  const { locale, product } = useStore()
  const t = dictionaryFor(locale)
  const root = useRef<HTMLElement>(null)
  const [zoomIndex, setZoomIndex] = useState<number | null>(null)
  const details = product.product_images.filter((i) => i.role === 'detail')

  useGSAP(
    () => {
      if (prefersReducedMotion()) return
      gsap.utils.toArray<HTMLElement>('[data-d="chapter"]').forEach((chapter) => {
        const frame = chapter.querySelector('[data-d="frame"]')
        const img = chapter.querySelector('[data-d="img"]')
        const text = chapter.querySelectorAll('[data-d="text"]')
        gsap
          .timeline({ scrollTrigger: { trigger: chapter, start: 'top 78%' } })
          .fromTo(frame, { clipPath: 'inset(100% 0% 0% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.4, ease: 'expo.out' })
          .fromTo(text, { y: 40, opacity: 0 }, { y: 0, opacity: 1, duration: 1, stagger: 0.1, ease: 'expo.out' }, 0.2)
        gsap.fromTo(
          img,
          { scale: 1.3, yPercent: -6 },
          { scale: 1.05, yPercent: 6, ease: 'none', scrollTrigger: { trigger: chapter, start: 'top bottom', end: 'bottom top', scrub: true } },
        )
      })
      gsap.fromTo(
        '[data-d="heading"]',
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 1.2, ease: 'expo.out', scrollTrigger: { trigger: '[data-d="heading"]', start: 'top 85%' } },
      )
    },
    { scope: root, dependencies: [details.length] },
  )

  if (details.length === 0) return null

  return (
    <section id="details" ref={root} className="relative bg-ivory-light px-5 py-24 md:px-10 md:py-36">
      <div data-d="heading" className="mx-auto max-w-[1200px] text-center">
        <p className="eyebrow text-gold">{t.story.eyebrow}</p>
        <h2 className="mt-4 font-display text-[clamp(2.25rem,6vw,4.5rem)] font-light leading-[1.05] text-burgundy rtl:leading-[1.3]">
          {t.story.heading}
        </h2>
      </div>

      <div className="mx-auto mt-16 flex max-w-[1200px] flex-col gap-24 md:mt-28 md:gap-40">
        {details.map((d, i) => (
          <article
            key={d.id}
            data-d="chapter"
            className={`grid items-center gap-8 md:grid-cols-2 md:gap-20 ${i % 2 ? 'md:[&>*:first-child]:order-2' : ''}`}
          >
            <button
              type="button"
              onClick={() => setZoomIndex(i)}
              aria-label={`${t.product.zoom} : ${pick(d, 'title', locale) || pick(d, 'alt', locale)}`}
              className="group relative block cursor-zoom-in"
            >
              <div data-d="frame" className="relative aspect-[4/5] overflow-hidden bg-ivory-dark">
                <Image
                  data-d="img"
                  src={mediaUrl(d.path)}
                  alt={pick(d, 'alt', locale)}
                  fill
                  sizes="(min-width: 768px) 50vw, 100vw"
                  className="object-cover"
                />
              </div>
              <span className="pointer-events-none absolute bottom-4 end-4 flex items-center gap-2 rounded-full bg-ivory-light/90 px-3.5 py-2 text-[0.6875rem] uppercase tracking-[0.18em] text-burgundy opacity-90 backdrop-blur transition-opacity group-hover:opacity-100 rtl:tracking-normal">
                <svg viewBox="0 0 24 24" className="size-3.5" fill="none" stroke="currentColor" strokeWidth="1.6">
                  <circle cx="11" cy="11" r="6.5" />
                  <path d="M16 16l4.5 4.5M11 8.5v5M8.5 11h5" />
                </svg>
                {t.story.zoomHint}
              </span>
            </button>

            <div className="md:px-6">
              <p data-d="text" className="font-display text-6xl font-light text-gold/70 md:text-7xl">
                {String(i + 1).padStart(2, '0')}
              </p>
              <h3 data-d="text" className="mt-3 font-display text-[clamp(2rem,4.5vw,3.25rem)] leading-[1.1] text-burgundy">
                {pick(d, 'title', locale)}
              </h3>
              <p data-d="text" className="mt-5 max-w-md text-[1.0625rem] leading-relaxed text-mute">
                {pick(d, 'caption', locale)}
              </p>
              <span data-d="text" className="mt-8 block h-px w-16 bg-gold" />
            </div>
          </article>
        ))}
      </div>

      {zoomIndex !== null ? (
        <ZoomViewer
          images={details.map((d) => ({ src: mediaUrl(d.path), alt: pick(d, 'alt', locale) }))}
          index={zoomIndex}
          onIndexChange={setZoomIndex}
          onClose={() => setZoomIndex(null)}
          labels={{ close: t.product.close, photo: t.product.photo }}
        />
      ) : null}
    </section>
  )
}
