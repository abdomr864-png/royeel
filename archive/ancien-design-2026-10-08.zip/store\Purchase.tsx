'use client'

import Image from 'next/image'
import { useEffect, useRef, useState } from 'react'
import { dictionaryFor } from '@/lib/i18n/dictionaries'
import { formatPrice } from '@/lib/format'
import { lines, pick } from '@/lib/localize'
import { mediaUrl } from '@/lib/supabase/env'
import { track } from '@/lib/tracking/client'
import { useStore } from './StoreContext'
import { Lens, useLens, ZoomViewer } from './ZoomViewer'

const LOW_STOCK = 3

export function Purchase() {
  const { product } = useStore()
  const section = useRef<HTMLElement>(null)

  // ViewContent fires once, when the product block is actually seen.
  useEffect(() => {
    const el = section.current
    if (!el) return
    const io = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return
        track('ViewContent', { value: product.price_mad, contentId: product.slug, contentName: product.name_fr })
        io.disconnect()
      },
      { threshold: 0.25 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [product])

  return (
    <section id="acheter" ref={section} className="scroll-mt-16 bg-ivory px-5 pb-20 pt-24 md:px-10 md:pb-28 md:pt-32">
      <div className="mx-auto grid max-w-[1300px] gap-10 md:grid-cols-[1.15fr_1fr] md:gap-16 lg:gap-24">
        <Gallery />
        <div className="md:sticky md:top-28 md:self-start">
          <ProductInfo />
          <Accordions />
        </div>
      </div>
    </section>
  )
}

function Gallery() {
  const { locale, product } = useStore()
  const t = dictionaryFor(locale)
  const images = [...product.product_images].sort(
    (a, b) => (a.role === b.role ? a.position - b.position : a.role === 'gallery' ? -1 : 1),
  )
  const [active, setActive] = useState(0)
  const [zoom, setZoom] = useState<number | null>(null)
  const track_ = useRef<HTMLDivElement>(null)
  const { lens, handlers } = useLens()

  // Keep the dots in sync with the swipeable strip on phones.
  function onScroll() {
    const el = track_.current
    if (!el) return
    const i = Math.round(Math.abs(el.scrollLeft) / el.clientWidth)
    if (i !== active) setActive(i)
  }

  function show(i: number) {
    setActive(i)
    const el = track_.current
    if (el) el.scrollTo({ left: (document.dir === 'rtl' ? -1 : 1) * i * el.clientWidth, behavior: 'smooth' })
  }

  if (images.length === 0) return <div className="aspect-[3/4] bg-ivory-dark" />

  return (
    <div className="md:grid md:grid-cols-[72px_1fr] md:gap-4">
      <div className="order-2 hidden flex-col gap-3 md:order-1 md:flex">
        {images.map((img, i) => (
          <button
            key={img.id}
            type="button"
            onClick={() => show(i)}
            aria-label={t.product.photo(i + 1, images.length)}
            aria-current={i === active}
            className={`relative aspect-[3/4] overflow-hidden transition-opacity ${i === active ? 'opacity-100 ring-1 ring-burgundy ring-offset-2 ring-offset-ivory' : 'opacity-55 hover:opacity-100'}`}
          >
            <Image src={mediaUrl(img.path)} alt="" fill sizes="72px" className="object-cover" />
          </button>
        ))}
      </div>

      <div className="relative order-1 md:order-2">
        <div
          ref={track_}
          onScroll={onScroll}
          className="flex snap-x snap-mandatory overflow-x-auto [scrollbar-width:none] md:overflow-hidden [&::-webkit-scrollbar]:hidden"
        >
          {images.map((img, i) => (
            <button
              key={img.id}
              type="button"
              onClick={() => setZoom(i)}
              aria-label={`${t.product.zoom} — ${t.product.photo(i + 1, images.length)}`}
              className="relative aspect-[3/4] w-full shrink-0 snap-center cursor-zoom-in overflow-hidden bg-ivory-dark"
              {...(i === active ? handlers : {})}
            >
              <Image
                src={mediaUrl(img.path)}
                alt={pick(img, 'alt', locale)}
                fill
                sizes="(min-width: 768px) 50vw, 100vw"
                quality={90}
                className="object-cover"
              />
              {lens && i === active ? <Lens src={mediaUrl(img.path)} lens={lens} /> : null}
            </button>
          ))}
        </div>
        <div className="mt-4 flex justify-center gap-1.5 md:hidden">
          {images.map((img, i) => (
            <span key={img.id} className={`h-1 rounded-full transition-all duration-300 ${i === active ? 'w-6 bg-burgundy' : 'w-1.5 bg-burgundy/25'}`} />
          ))}
        </div>
      </div>

      {zoom !== null ? (
        <ZoomViewer
          images={images.map((img) => ({ src: mediaUrl(img.path), alt: pick(img, 'alt', locale) }))}
          index={zoom}
          onIndexChange={setZoom}
          onClose={() => setZoom(null)}
          labels={{ close: t.product.close, photo: t.product.photo }}
        />
      ) : null}
    </div>
  )
}

function ProductInfo() {
  const { locale, product, sizeId, setSizeId, quantity, setQuantity, openCheckout, sizeNudge, nudgeSize } = useStore()
  const t = dictionaryFor(locale)
  const [guideOpen, setGuideOpen] = useState(false)
  // Shakes the size buttons each time someone orders without choosing a size.
  const shake = sizeNudge > 0 && !sizeId
  const sizes = product.product_sizes
  const selected = sizes.find((s) => s.id === sizeId)
  const allSoldOut = sizes.length > 0 && sizes.every((s) => s.stock <= 0)
  const maxQty = Math.min(3, selected?.stock ?? 1)
  const guide = pick(product, 'size_guide', locale)

  function order() {
    if (!selected) {
      nudgeSize()
      return
    }
    openCheckout()
  }

  return (
    <div>
      <p className="eyebrow text-gold">{dictionaryFor(locale).hero.eyebrow}</p>
      <h2 className="mt-3 font-display text-[clamp(2.25rem,5vw,3.5rem)] font-light leading-[1.05] text-burgundy rtl:leading-[1.3]">
        {pick(product, 'name', locale)}
      </h2>
      <p className="mt-2 text-mute">{pick(product, 'subtitle', locale)}</p>
      <p className="mt-5 font-display text-3xl text-ink">{formatPrice(product.price_mad, locale)}</p>

      {pick(product, 'color_name', locale) ? (
        <div className="mt-8 flex items-center gap-3 text-sm">
          <span className="text-mute">{t.product.color}</span>
          <span
            className="size-5 rounded-full border border-ink/15 ring-2 ring-ivory ring-offset-1 ring-offset-ink/20"
            style={{ background: product.color_hex ?? undefined }}
          />
          <span className="text-ink">{pick(product, 'color_name', locale)}</span>
        </div>
      ) : null}

      <div className="mt-8">
        <div className="flex items-baseline justify-between">
          <span id="size-label" className={`text-sm ${shake ? 'text-burgundy' : 'text-mute'}`}>
            {selected ? `${t.product.size} : ${selected.label}` : t.product.chooseSize}
          </span>
          {guide ? (
            <button type="button" onClick={() => setGuideOpen(true)} className="text-sm text-ink underline decoration-gold underline-offset-4">
              {t.product.sizeGuide}
            </button>
          ) : null}
        </div>
        <div
          key={sizeNudge}
          role="radiogroup"
          aria-labelledby="size-label"
          className={`mt-3 grid grid-cols-4 gap-2 ${shake ? 'animate-[shake_0.5s_ease-in-out]' : ''}`}
        >
          {sizes.map((s) => {
            const out = s.stock <= 0
            const on = s.id === sizeId
            return (
              <button
                key={s.id}
                type="button"
                role="radio"
                aria-checked={on}
                disabled={out}
                onClick={() => setSizeId(s.id)}
                className={`relative h-12 border text-sm tracking-wide transition-all duration-300 ${
                  out
                    ? 'cursor-not-allowed border-line text-mute/50'
                    : on
                      ? 'border-burgundy bg-burgundy text-ivory'
                      : 'border-line bg-ivory-light text-ink hover:border-burgundy'
                }`}
              >
                {s.label}
                {out ? (
                  <>
                    <span aria-hidden className="absolute inset-0 m-auto h-px w-[70%] -rotate-12 bg-mute/40" />
                    <span className="sr-only"> — {t.product.soldOut}</span>
                  </>
                ) : null}
              </button>
            )
          })}
        </div>
        {selected && selected.stock <= LOW_STOCK ? (
          <p className="mt-3 flex items-center gap-2 text-sm text-burgundy">
            <span className="size-1.5 animate-pulse rounded-full bg-burgundy" />
            {t.product.lastPieces(selected.stock)}
          </p>
        ) : null}
      </div>

      {selected && maxQty > 1 ? (
        <div className="mt-6 flex items-center gap-4">
          <span className="text-sm text-mute">{t.product.quantity}</span>
          <div className="flex items-center border border-line">
            <button type="button" aria-label="−" onClick={() => setQuantity(Math.max(1, quantity - 1))} className="size-10 text-lg text-ink disabled:opacity-30" disabled={quantity <= 1}>
              −
            </button>
            <span className="w-8 text-center text-sm tabular-nums" aria-live="polite">
              {quantity}
            </span>
            <button type="button" aria-label="+" onClick={() => setQuantity(Math.min(maxQty, quantity + 1))} className="size-10 text-lg text-ink disabled:opacity-30" disabled={quantity >= maxQty}>
              +
            </button>
          </div>
        </div>
      ) : null}

      <button
        type="button"
        onClick={order}
        disabled={allSoldOut}
        className="group relative mt-8 flex h-14 w-full items-center justify-center gap-3 overflow-hidden bg-burgundy text-[0.8125rem] font-medium uppercase tracking-[0.22em] text-ivory transition-colors disabled:cursor-not-allowed disabled:bg-mute rtl:tracking-normal rtl:text-base"
      >
        <span className="relative z-10">
          {allSoldOut ? t.product.allSoldOut : `${t.product.order} — ${formatPrice(product.price_mad * (selected ? quantity : 1), locale)}`}
        </span>
        <span className="absolute inset-0 origin-left scale-x-0 bg-burgundy-soft transition-transform duration-500 ease-luxe group-hover:scale-x-100 group-disabled:hidden rtl:origin-right" />
      </button>

      <ul className="mt-6 grid gap-2.5 text-sm text-mute">
        {[t.perks.delivery, t.perks.cod, t.perks.exchange].map((p) => (
          <li key={p.title} className="flex items-center gap-3">
            <span className="size-1 rotate-45 bg-gold" />
            <span>
              <span className="text-ink">{p.title}</span> · {p.text}
            </span>
          </li>
        ))}
      </ul>

      {guideOpen ? (
        <div role="dialog" aria-modal="true" aria-label={t.product.sizeGuide} className="fixed inset-0 z-[80] grid place-items-center bg-ink/50 p-5 backdrop-blur-sm" onClick={() => setGuideOpen(false)}>
          <div className="w-full max-w-md bg-ivory-light p-7" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="font-display text-2xl text-burgundy">{t.product.sizeGuide}</h3>
              <button type="button" onClick={() => setGuideOpen(false)} aria-label={t.product.close} className="text-2xl text-mute">
                ×
              </button>
            </div>
            <div className="mt-4 space-y-1.5 text-sm leading-relaxed text-ink">
              {lines(guide).map((l) => (
                <p key={l}>{l}</p>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}

function Accordions() {
  const { locale, product } = useStore()
  const t = dictionaryFor(locale)
  const details = lines(pick(product, 'details', locale))
  const items = [
    { title: t.product.description, body: <p>{pick(product, 'description', locale)}</p>, open: true },
    details.length
      ? {
          title: t.product.details,
          body: (
            <ul className="space-y-2">
              {details.map((d) => (
                <li key={d} className="flex gap-3">
                  <span className="mt-2.5 size-1 shrink-0 rotate-45 bg-gold" />
                  {d}
                </li>
              ))}
            </ul>
          ),
          open: false,
        }
      : null,
    { title: t.product.delivery, body: <p>{t.product.deliveryText}</p>, open: false },
  ].filter((x) => x !== null)

  return (
    <div className="mt-10 border-t border-line">
      {items.map((item) => (
        <details key={item.title} open={item.open} className="group border-b border-line">
          <summary className="flex cursor-pointer list-none items-center justify-between py-5 text-[0.8125rem] uppercase tracking-[0.18em] text-ink rtl:tracking-normal rtl:text-base [&::-webkit-details-marker]:hidden">
            {item.title}
            <span className="relative size-3">
              <span className="absolute inset-x-0 top-1/2 h-px bg-current" />
              <span className="absolute inset-y-0 start-1/2 w-px bg-current transition-transform duration-300 group-open:rotate-90 group-open:opacity-0" />
            </span>
          </summary>
          <div className="pb-6 text-[0.95rem] leading-relaxed text-mute">{item.body}</div>
        </details>
      ))}
    </div>
  )
}
